# Prediction-using-Supervised-ML-
Predict the percentage of an student based on the no. of study hours. This is a simple linear regression task as it involves just 2 variables.  Dataset link : http://bit.ly/w-data You can use above link to download the dataset.
